#!/usr/bin/env python3
"""Probe TOM cookie TTL from expires vs file mtime. Never prints cookie values."""
import json
import os
from datetime import datetime, timedelta, timezone

COOKIE_PATH = "/home/winit/AI_EXPERT/TOM/共享认证/playwright_cookies.json"
META_PATH = "/home/winit/AI_EXPERT/TOM/共享认证/playwright_session_meta.json"
SH = timezone(timedelta(hours=8))


def ts(value):
    if value is None:
        return None
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    if n > 1e12:
        n = n / 1000.0
    if n <= 0:
        return None
    return datetime.fromtimestamp(n, tz=timezone.utc).astimezone(SH)


def iso(dt):
    return dt.isoformat(sep=" ", timespec="seconds") if dt else "-"


st = os.stat(COOKIE_PATH)
mtime = datetime.fromtimestamp(st.st_mtime, tz=SH)

captured = None
if os.path.exists(META_PATH):
    meta = json.load(open(META_PATH, encoding="utf-8"))
    captured_raw = meta.get("captured_at")
    if captured_raw:
        captured = datetime.fromtimestamp(float(captured_raw), tz=timezone.utc).astimezone(SH)

cookies = json.load(open(COOKIE_PATH, encoding="utf-8"))
rows = []
session_like = 0
persistent = 0
for c in cookies:
    name = str(c.get("name") or "")
    domain = str(c.get("domain") or "")
    exp = ts(c.get("expires"))
    raw_exp = c.get("expires")
    sess = raw_exp in (None, -1, 0, "-1", "0") or exp is None
    if sess:
        session_like += 1
        hours_mtime = None
        hours_captured = None
        kind = "session"
    else:
        persistent += 1
        kind = "persistent"
        hours_mtime = (exp - mtime).total_seconds() / 3600.0
        hours_captured = (exp - captured).total_seconds() / 3600.0 if captured else None
    rows.append(
        {
            "kind": kind,
            "name": name,
            "domain": domain,
            "exp": exp,
            "hours_mtime": hours_mtime,
            "hours_captured": hours_captured,
        }
    )

print("file_mtime_cst", iso(mtime))
print("captured_at_cst", iso(captured))
print("now_cst", iso(datetime.now(SH)))
print("cookie_count", len(cookies), "persistent", persistent, "session_or_no_expires", session_like)
print("--- persistent cookies ---")
for r in sorted(rows, key=lambda r: (r["kind"] != "persistent", r["hours_mtime"] if r["hours_mtime"] is not None else 1e9)):
    if r["kind"] != "persistent":
        continue
    hc = f"{r['hours_captured']:.2f}" if r["hours_captured"] is not None else "-"
    print(
        f"{r['name']}\t{r['domain']}\texpires={iso(r['exp'])}\t"
        f"hours_from_mtime={r['hours_mtime']:.2f}\thours_from_captured={hc}"
    )

print("--- likely auth cookies ---")
keywords = ("token", "sid", "session", "iam", "auth", "sso", "jwt", "jsession", "castgc", "tgt")
for r in rows:
    low = r["name"].lower()
    if not (any(k in low for k in keywords) or "cniam" in r["domain"].lower() or "iam" in r["domain"].lower()):
        continue
    if r["kind"] == "session":
        print(f"{r['name']}\t{r['domain']}\tsession_cookie")
    else:
        hc = f"{r['hours_captured']:.2f}" if r["hours_captured"] is not None else "-"
        print(
            f"{r['name']}\t{r['domain']}\texpires={iso(r['exp'])}\t"
            f"hours_from_mtime={r['hours_mtime']:.2f}\thours_from_captured={hc}"
        )

pers = [r["hours_mtime"] for r in rows if r["kind"] == "persistent" and r["hours_mtime"] is not None]
if pers:
    pers_sorted = sorted(pers)
    print("--- summary hours_from_mtime ---")
    print("min", round(min(pers), 2))
    print("p50", round(pers_sorted[len(pers_sorted) // 2], 2))
    print("max", round(max(pers), 2))
    print("count_lt_3h", sum(1 for h in pers if h < 3))
    print("count_3_to_13h", sum(1 for h in pers if 3 <= h < 13))
    print("count_13h_plus", sum(1 for h in pers if h >= 13))
