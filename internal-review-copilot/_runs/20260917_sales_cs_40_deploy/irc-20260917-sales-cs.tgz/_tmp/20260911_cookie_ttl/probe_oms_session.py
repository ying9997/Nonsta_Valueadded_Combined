#!/usr/bin/env python3
"""Check whether OMS still accepts the saved cookies. No cookie values printed."""
import json
import ssl
from urllib.request import Request, build_opener, HTTPSHandler, HTTPRedirectHandler

COOKIE_PATH = "/home/winit/AI_EXPERT/TOM/共享认证/playwright_cookies.json"
LIST_PAGE = "https://cnomstom.winit.com.cn/VasOrder/index"


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


cookies = json.load(open(COOKIE_PATH, encoding="utf-8"))
header = "; ".join(
    f"{c['name']}={c['value']}" for c in cookies if c.get("name") and c.get("value")
)
req = Request(
    LIST_PAGE,
    headers={
        "User-Agent": "Mozilla/5.0",
        "Cookie": header,
    },
)
ctx = ssl._create_unverified_context()
opener = build_opener(NoRedirect, HTTPSHandler(context=ctx))
try:
    resp = opener.open(req, timeout=30)
    status = resp.status
    url = resp.geturl()
    body = resp.read(4000).decode("utf-8", "replace")
except Exception as e:
    # urllib raises on 302 when NoRedirect is used
    if hasattr(e, "code"):
        status = e.code
        url = e.headers.get("Location", "")
        body = ""
        print("http_status", status)
        print("location", url[:200])
        print("redirected_to_iam", "cniam" in url or "#/login" in url)
        raise SystemExit(0)
    print("error", type(e).__name__, str(e)[:200])
    raise SystemExit(1)

print("http_status", status)
print("final_url", url[:200])
print("redirected_to_iam", "cniam" in url or "#/login" in url)
print("has_csrf", "window.__CSRF_TOKEN__" in body)
print("looks_like_login", "登录" in body and "password" in body.lower())
