#!/bin/bash
set -euo pipefail
LINE='*/10 * * * * cd /home/winit/AI_EXPERT/TOM/共享认证 && python3 auto_login.py >> /tmp/auto_login.log 2>&1'
TMP=$(mktemp)
crontab -l 2>/dev/null > "$TMP" || true
if grep -F "AI_EXPERT/TOM/共享认证 && python3 auto_login.py" "$TMP" >/dev/null; then
  echo "cron already present"
else
  printf '\n# internal-review-copilot TOM Cookie 续期（有效期约 20 分钟，一半间隔）\n%s\n' "$LINE" >> "$TMP"
  crontab "$TMP"
  echo "cron added"
fi
rm -f "$TMP"
crontab -l | grep -n "auto_login" || true
