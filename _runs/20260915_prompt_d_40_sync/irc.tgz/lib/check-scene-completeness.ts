/**
 * L2.5 scene-level completeness: required info (LLM) + attachments (rules).
 *
 * Pipeline calls this after match-template succeeds. `check-completeness.ts`
 * is kept for attachment rules / old evals; pipeline no longer calls it
 * directly.
 */

import { checkCompleteness } from "./check-completeness.ts";
import { callChat, extractFirstJsonObject, type LlmConfig } from "./llm-client.ts";
import { findScenarioCard, type RequirementInfoField, type ScenarioCard } from "./scenario-cards.ts";
import type { CompletenessResult, ContextFacts, MatchResult } from "./types.ts";

export interface SceneInfoCheck {
  field: string;
  present: boolean;
  evidence: string;
}

export interface SceneCompletenessResult {
  complete: boolean;
  missingInfo: string[];
  missingAttachments: string[];
  clarificationPrompts: string[];
  sceneKey: string;
  infoChecks: SceneInfoCheck[];
  infoCheckSkipped: boolean;
  infoCheckError: string;
  attachment: CompletenessResult;
}

export interface CheckSceneCompletenessOptions {
  /** Dry-run / eval: attachments only, no info LLM. */
  skipInfoLlm?: boolean;
  llmConfig?: LlmConfig;
}

function shortSceneName(sceneName: string): string {
  return sceneName.replace(/^[§\d.]+\s*/, "").replace(/[“”"]/g, "").trim();
}

function requiredInfoOf(card: ScenarioCard | undefined): RequirementInfoField[] {
  return (card?.requiredInfoFields || []).filter((item) => item.required && String(item.field || "").trim());
}

function stripMissingSuffix(text: string): string {
  return text.replace(/未说明$/, "").replace(/未上传$/, "").trim();
}

export function parseInfoLlmResponse(
  raw: string,
  requiredInfo: RequirementInfoField[],
): { missing: string[]; checks: SceneInfoCheck[] } {
  let parsed: { missing?: unknown; checks?: unknown } = {};
  try {
    parsed = JSON.parse(extractFirstJsonObject(raw) || raw || "{}") as {
      missing?: unknown;
      checks?: unknown;
    };
  } catch {
    parsed = {};
  }

  const byField = new Map<string, RequirementInfoField>();
  for (const item of requiredInfo) byField.set(item.field, item);

  const checks: SceneInfoCheck[] = [];
  if (Array.isArray(parsed.checks)) {
    for (const row of parsed.checks) {
      if (!row || typeof row !== "object") continue;
      const rec = row as { field?: unknown; present?: unknown; evidence?: unknown };
      const field = String(rec.field || "").trim();
      if (!field) continue;
      checks.push({
        field,
        present: Boolean(rec.present),
        evidence: String(rec.evidence || "").trim(),
      });
    }
  }

  if (!checks.length && Array.isArray(parsed.missing)) {
    const missingNames = new Set(
      parsed.missing.map((item) => stripMissingSuffix(String(item || "").trim())).filter(Boolean),
    );
    for (const item of requiredInfo) {
      const present = !missingNames.has(item.field) && ![...missingNames].some((name) => name.includes(item.field));
      checks.push({ field: item.field, present, evidence: "" });
    }
  }

  if (!checks.length) {
    for (const item of requiredInfo) {
      checks.push({ field: item.field, present: true, evidence: "" });
    }
  }

  const known = new Set(requiredInfo.map((item) => item.field));
  const missing = checks
    .filter((item) => !item.present && (!known.size || known.has(item.field) || [...known].some((f) => item.field.includes(f))))
    .map((item) => (item.field.endsWith("未说明") ? item.field : `${item.field}未说明`));

  return { missing, checks };
}

function buildInfoPrompt(customerIntent: string, requiredInfo: RequirementInfoField[]): string {
  const lines = requiredInfo.map((item, i) => {
    const examples = (item.examples || []).filter(Boolean).slice(0, 5).join("、");
    const exampleBit = examples ? `（例如：${examples}）` : "";
    return `${i + 1}. ${item.field}：${item.description || ""}${exampleBit}`;
  });
  return `你是增值审核完整性检查员。

已确认场景需要以下关键信息：
${lines.join("\n")}

客户需求描述：
"${customerIntent.replace(/"/g, "＂")}"

请判断客户需求描述里是否包含了上述每条关键信息。
只要能从描述中推断出来就算有，不需要原文一模一样。

输出 JSON：
{"checks":[{"field":"处理范围","present":true,"evidence":"264箱"},{"field":"辨识方法","present":false,"evidence":""}],"missing":["辨识方法未说明"]}
全部齐全时 missing 为空数组。只判断上面列出的字段。`;
}

export async function checkInfoWithLlm(
  customerIntent: string,
  requiredInfo: RequirementInfoField[],
  config: LlmConfig,
): Promise<{ missing: string[]; checks: SceneInfoCheck[]; error: string }> {
  if (!requiredInfo.length) return { missing: [], checks: [], error: "" };
  try {
    const response = await callChat(config, [{ role: "user", content: buildInfoPrompt(customerIntent, requiredInfo) }], {
      jsonMode: true,
      maxTokens: 800,
      temperature: 0,
    });
    const parsed = parseInfoLlmResponse(response, requiredInfo);
    return { ...parsed, error: "" };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      missing: [],
      checks: requiredInfo.map((item) => ({ field: item.field, present: true, evidence: "" })),
      error: message,
    };
  }
}

export function buildClarificationPrompts(
  missingInfo: string[],
  missingAttachments: string[],
  extraFieldPrompts: string[],
  card: ScenarioCard | undefined,
): string[] {
  const scene = shortSceneName(card?.sceneName || "");
  const prompts: string[] = [];
  for (const info of missingInfo) {
    const what = stripMissingSuffix(info) || info;
    prompts.push(scene ? `本场景（${scene}）需要知道${what}，请补充。` : `需要知道${what}，请补充。`);
  }
  for (const att of missingAttachments) {
    prompts.push(`请上传「${att}」。`);
  }
  for (const extra of extraFieldPrompts) {
    if (extra) prompts.push(extra);
  }
  return prompts;
}

/**
 * Merge attachment rules (checkCompleteness) with LLM info checks.
 * LLM runs only when the scene matched and skipInfoLlm is false.
 */
export async function checkSceneCompleteness(
  customerIntent: string,
  contextFacts: ContextFacts,
  matchResult: MatchResult,
  options: CheckSceneCompletenessOptions = {},
): Promise<SceneCompletenessResult> {
  const attachment = checkCompleteness(contextFacts, matchResult);
  const card = findScenarioCard(matchResult.sceneKey);
  const requiredInfo = requiredInfoOf(card);
  const missingAttachments = [...attachment.missingAttachments];
  const extraFieldPrompts = attachment.missingFields
    .filter((item) => !missingAttachments.includes(item.field))
    .map((item) => item.clarificationPrompt);

  let missingInfo: string[] = [];
  let infoChecks: SceneInfoCheck[] = requiredInfo.map((item) => ({
    field: item.field,
    present: true,
    evidence: "",
  }));
  let infoCheckSkipped = true;
  let infoCheckError = "";

  if (!options.skipInfoLlm && requiredInfo.length && options.llmConfig) {
    infoCheckSkipped = false;
    const judged = await checkInfoWithLlm(customerIntent, requiredInfo, options.llmConfig);
    missingInfo = judged.missing;
    infoChecks = judged.checks;
    infoCheckError = judged.error;
  }

  const complete = missingInfo.length === 0 && attachment.complete;
  return {
    complete,
    missingInfo,
    missingAttachments,
    clarificationPrompts: buildClarificationPrompts(missingInfo, missingAttachments, extraFieldPrompts, card),
    sceneKey: matchResult.sceneKey,
    infoChecks,
    infoCheckSkipped,
    infoCheckError,
    attachment,
  };
}

export function toCompletenessResult(scene: SceneCompletenessResult): CompletenessResult {
  return {
    ...scene.attachment,
    complete: scene.complete,
    missingAttachments: scene.missingAttachments,
    missingInfo: scene.missingInfo,
    infoChecks: scene.infoChecks,
    infoCheckSkipped: scene.infoCheckSkipped,
    infoCheckError: scene.infoCheckError,
  };
}
