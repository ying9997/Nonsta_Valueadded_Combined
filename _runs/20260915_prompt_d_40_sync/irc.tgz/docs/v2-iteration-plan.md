# V2 迭代计划

> V1 已部署（或即将部署）到 40。本文档规划部署后的第一轮迭代。
> 每项标注：目标、做法、验证方式、依赖关系、预计工作量。

---

## 一、补齐 43 张场景卡的 requiredInfoFields

### 目标

当前 75 张场景卡中 32 张有 `requiredInfoFields`（L2.5 能精准追问），43 张没有（L2.5 跳过信息检查直接放行）。补齐后所有场景都能精准追问。

### 现状

| 步骤 | 状态 |
|------|------|
| G-1 提炼脚本（extract-scene-requirement-fields.ts） | ✅ 写好了 |
| G-1 跑了 38 个场景 | ✅ 产出在 `_runs/20260914_scene_requirement_fields/` |
| G-1b 模糊匹配 OMS 码脚本（fuzzy-match-oms-codes.ts） | ✅ 写好了 |
| G-1b 跑模糊匹配 | ❌ 脚本写了没跑 |
| 写入场景卡（apply-requirement-fields.ts） | ✅ 已跑，写入了 32 张 |

### 做法

```
Step 1：跑 G-1b 模糊匹配
  → fuzzy-match-oms-codes.ts 给 43 张无码卡找 OMS 码
  → 预计 15-25 张能匹配上
  → 产出匹配报告，人工确认

Step 2：确认后补码到场景卡
  → 把匹配上的 OMS 码写入 omsSceneCode

Step 3：重跑 G-1 提炼
  → 对新补码的场景跑 extract-scene-requirement-fields.ts
  → 产出 requiredInfoFields

Step 4：写入场景卡
  → apply-requirement-fields.ts 补充写入

Step 5：剩余匹配不上的（预计 15-20 张）
  → 没有历史数据，手动写 requiredInfoFields
  → 或等这些场景线上跑出数据后再补
```

### 验证

- 跑完后统计：75 张卡中有 requiredInfoFields 的比例（目标 ≥ 50 张）
- 用之前 E2E 的 5 条待审核单重跑，看 L2.5 追问是否变化

### 预计工作量

Step 1-4：0.5 天（脚本都有，跑一下就行）
Step 5：看情况，可以后补

---

## 二、场景匹配准确率提升 + 验证

### 目标

用已有的测试集（golden labels + 历史跑批），对比增强前后的场景匹配准确率。增强手段：requiredInfoFields 补齐 + RAG 案例库 + 其他。

### 验证方案

**用同一批测试数据跑 A/B 对比：**

| 配置 | 场景卡 | requiredInfoFields | RAG | 对比什么 |
|------|--------|-------------------|-----|---------|
| 基线（当前） | 75 张 | 32 张有 | 关 | — |
| 增强 A | 75 张 | 50+ 张有 | 关 | requiredInfoFields 补齐的独立贡献 |
| 增强 B | 75 张 | 32 张有 | 开 | RAG 的独立贡献 |
| 增强 C | 75 张 | 50+ 张有 | 开 | 两者叠加 |

**测试数据：**

| 数据集 | 条数 | 用途 |
|--------|------|------|
| t14-golden.jsonl | 5 条 | 精准评测（有 expectedScene） |
| 历史跑批试点 20 条 | 20 条 | 覆盖度评测（有 OMS 审核员实际选的场景） |
| 40 线上跑的真实单（从 case-store 取） | 若干 | 真实场景分布评测 |

**指标：**

| 指标 | 含义 |
|------|------|
| 场景精准匹配率 | AI 判的 = 审核员选的 |
| 场景可接受匹配率 | AI 判的在 acceptableScenes 内 |
| L2 转人工率 | 转人工的单占比（越低越好，说明 AI 能处理更多） |
| L2.5 追问率 | 需要追问信息的单占比（不是越低越好——该追问的要追问） |
| L4 到达率 | 能走到 SOP 生成的单占比 |

**跑评测用现有脚本：** `run-objective-eval.ts`（精准评测）+ `run-historical-batch.ts`（覆盖度评测）

### 做法

```
Step 1：跑基线（当前配置）
  → 用 5 条 golden + 20 条历史 → 记录指标

Step 2：补齐 requiredInfoFields（一、的产出）
  → 重跑同一批数据 → 对比指标（增强 A）

Step 3：开 RAG（RAG_ENABLED=1）
  → 在增强 A 的基础上开 RAG → 对比指标（增强 C）
  → 也单独跑只开 RAG 不补卡的（增强 B）

Step 4：汇总对比报告
```

### 预计工作量

Step 1-3：各 0.5 小时（跑脚本等结果）
Step 4：0.5 天（分析 + 写报告）

---

## 三、RAG 案例库优化

### 当前状态

- 入库案例库：105 条（inbound-cases.jsonl）
- 库内案例库：122 KB（instock-cases.jsonl）
- BM25 内存检索，阈值 ≥ 1.0 才注入 prompt
- 默认关（RAG_ENABLED=0）

### 做法

```
Step 1：在二、的对比中验证 RAG 是否有帮助
  → 如果增强 B/C 的准确率 > 基线 → RAG 有用 → 默认开
  → 如果没提升甚至降了 → 检查案例库质量 / 检索召回

Step 2：如果 RAG 有帮助
  → 调优 BM25 阈值（当前 1.0 可能太高）
  → 检查案例库覆盖度（43 张无 requiredInfoFields 的场景是否也缺案例）
  → 补充案例库

Step 3：如果 RAG 没帮助
  → 检查召回质量（top3 召回的场景对不对）
  → 可能需要换检索方式（BM25 → embedding 向量检索）
  → 记到 pending-hypotheses 后续再做
```

### 依赖

依赖二、的评测结果。

---

## 四、Slot Filling（跨轮渐进补全）

### 当前状态

已记录在 `pending-hypotheses.md` H9。设计完成，未实现。

### 做法

```
Step 1：在 CaseRecord 加 slots 字段
Step 2：L2.5 支持传入上轮槽位状态
Step 3：每轮只追问 1-2 个最关键的未填槽位
Step 4：飞书卡片展示"已确认 ✓"和"待补充 ❓"
```

### 依赖

依赖一、完成（场景卡有 requiredInfoFields 才有槽位定义）。

### 预计工作量

2 天。

---

## 五、其他 V2 优化项

| 优化 | 节点 | 做法 | 依赖 | 工作量 |
|------|------|------|------|--------|
| SOP 对照知识库模板检查 | L4 | Reflection 时传入知识库标准步骤，检查"该场景的 SOP 应该有 N 步，AI 写了几步" | 无 | 1 天 |
| 异常名称→场景配置表 | L2 | 业务方维护飞书多维表格，pipeline 定期同步 | 业务方配合 | 1 天 |
| 人工覆盖 + badcase 记录 | 全节点 | 审核员话题回复"强制场景：XX"/"强制通过附件" → 覆盖 AI 判断 + 记 badcase | 无 | 1.5 天 |
| OMS 状态同步 | 全局 | 定时查 OMS 订单状态，审核员直接在 OMS 操作的同步到 case-store | 无 | 1 天 |

---

## 执行顺序

```
部署 V1 到 40
    ↓
一、补齐 43 张 requiredInfoFields（0.5 天）
    ↓
二、场景匹配准确率 A/B/C 对比（1 天）
    ↓ 根据结果决定
三、RAG 是否默认开（0.5 天）
    ↓
四、Slot Filling（2 天）
    ↓
五、其他优化按优先级排
```

**一和二可以并行启动，三依赖二的结果，四依赖一。**

---

## 验收标准

| 阶段 | 达标标准 |
|------|---------|
| 一完成 | ≥ 50 张场景卡有 requiredInfoFields |
| 二完成 | 有 A/B/C/基线 四组对比报告，指标清晰 |
| 三完成 | RAG 开/关有数据支撑的决策 |
| 四完成 | 飞书追问从"一次列 5 个"变成"每轮 1-2 个" |
